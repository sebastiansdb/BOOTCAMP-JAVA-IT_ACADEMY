package n1exercici1.products.enums;

public enum MadeOf {
    WOOD, PLASTIC
}

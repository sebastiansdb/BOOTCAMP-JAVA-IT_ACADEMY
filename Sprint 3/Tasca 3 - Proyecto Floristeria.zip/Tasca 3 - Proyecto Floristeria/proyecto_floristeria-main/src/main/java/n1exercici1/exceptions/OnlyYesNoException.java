package n1exercici1.exceptions;

public class OnlyYesNoException extends Exception {

    public OnlyYesNoException(String message){
        super(message);
    }
}

rootProject.name = "S3.03.DevelopersTeam"


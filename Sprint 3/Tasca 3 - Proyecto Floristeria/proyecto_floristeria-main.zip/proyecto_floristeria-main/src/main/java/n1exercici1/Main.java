package n1exercici1;

import n1exercici1.getDataFromOutside.TxtReader;

public class Main {
    public static void main(String[] args) {
        App.runApp();
    }
}
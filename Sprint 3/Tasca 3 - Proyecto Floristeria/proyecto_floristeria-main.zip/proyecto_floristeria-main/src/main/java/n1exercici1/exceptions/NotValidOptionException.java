package n1exercici1.exceptions;

public class NotValidOptionException extends Exception {

    public NotValidOptionException(String message){
        super(message);
    }
}

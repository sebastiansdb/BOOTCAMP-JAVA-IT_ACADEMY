package n1exercici1.exceptions;

public class ProductDoesNotExistsException extends Exception {

    public ProductDoesNotExistsException(String message){
        super(message);
    }
}
